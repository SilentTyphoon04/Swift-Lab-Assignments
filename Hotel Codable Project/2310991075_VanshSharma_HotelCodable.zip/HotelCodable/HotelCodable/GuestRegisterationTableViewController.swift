//
//  GuestRegisterationTableViewController.swift
//  HotelCodable
//
//  Created by Student on 27/08/25.
//

import UIKit

class GuestRegisterationTableViewController: UITableViewController,SelectRoomTypeTableViewControllerDelegate{
    
    var roomTypeReceived: RoomType?
    var registereddata: Registration?
    
    @IBOutlet weak var fname: UITextField!
    @IBOutlet weak var lname: UITextField!
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var checkinLabel: UILabel!
    @IBOutlet weak var checkoutLabel: UILabel!
    @IBOutlet weak var checkinDate: UIDatePicker!
    @IBOutlet weak var checkoutDate: UIDatePicker!
    
    @IBOutlet weak var AdultCountLabel: UILabel!
    @IBOutlet weak var ChildrenCountLabel: UILabel!
    @IBOutlet weak var AdultStepper: UIStepper!
    @IBOutlet weak var ChildrenStepper: UIStepper!
    
    @IBOutlet weak var wifiSwitch: UISwitch!
    
    @IBOutlet weak var roomTypeLabel: UILabel!
    
    @IBOutlet weak var DoneButton: UIBarButtonItem!
    
    
    @IBOutlet weak var numofnights: UILabel!
    @IBOutlet weak var chargesduration: UILabel!
    @IBOutlet weak var roomprices: UILabel!
    @IBOutlet weak var typesofroom: UILabel!
    @IBOutlet weak var wifiprice: UILabel!
    @IBOutlet weak var wifichoice: UILabel!
    @IBOutlet weak var totalprice: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let midnightToday = Calendar.current.startOfDay(for: Date())
        checkinDate.minimumDate = midnightToday
        checkinDate.date = midnightToday
        updateDateViews()
        updateNumberOfGuets()
        updateRoomType()
        updatesummary()
        updateDoneButtonState()
        loadregistereddata()
    }

    let checkindateindexpath = IndexPath(row: 1, section: 1)
    let checkindatelabelindexpath = IndexPath(row: 0, section: 1)
    let checkoutdateindexpath = IndexPath(row: 3, section: 1)
    let checkoutdatelabelindexpath = IndexPath(row: 2, section: 1)
    var checkinpickervisible: Bool = false{
        didSet {
            checkinDate.isHidden = !checkinpickervisible
        }
    }
    var checkoutpickervisible: Bool = false{
        didSet {
            checkoutDate.isHidden = !checkoutpickervisible
        }
    }
    
    var registeration : Registration?{
        guard let roomType = roomTypeReceived else { return nil }
        let firstName = fname.text ?? ""
        let lastName = lname.text ?? ""
        let email = email.text ?? ""
        let checkindate = checkinDate.date
        let checkoutdate = checkoutDate.date
        let numberofaduts = Int(AdultStepper.value)
        let numberofchildren = Int(ChildrenStepper.value)
        let haswifi = wifiSwitch.isOn
        
        return Registration(
            firstName: firstName,
            lastName: lastName,
            emailAddress: email,
            checkInDate: checkindate,
            checkOutDate: checkoutdate,
            numberOfAdults: numberofaduts,
            numberOfChildren: numberofchildren,
            wifi: haswifi,
            roomType: roomType
        )
    }
    
    @IBSegueAction func selectRoomType(_ coder: NSCoder) -> SelectRoomTypeTableViewController? {
        let selectRoomTypeController = SelectRoomTypeTableViewController (coder: coder)
        selectRoomTypeController?.delegate = self
        selectRoomTypeController?.storedroomtype = roomTypeReceived
        return selectRoomTypeController
    }
    
//    @IBAction func DoneButtonTapped(_ sender: UIBarButtonItem) {
//        let firstName = fname.text ?? ""
//        let lastName = lname.text ?? ""
//        let email = email.text ?? ""
//        let checkindate = checkinDate.date
//        let checkoutdate = checkoutDate.date
//        let numberofaduts = Int(AdultStepper.value)
//        let numberofchildren = Int(ChildrenStepper.value)
//        let haswifi = wifiSwitch.isOn
//        let roomChoice = roomTypeReceived?.name ?? "Not Set"
//        print( "DONE TAPPED")
//        print("firstName: \(firstName) ")
//        print ("lastName: \(lastName) ")
//        print ( "email: \(email)")
//        print("Check in date : \(checkindate)")
//        print("Check - out date : \(checkoutdate)")
//        print("Number of Adults : \(numberofaduts)")
//        print("Number of Children : \(numberofchildren)")
//        print("wifi : \(haswifi)")
//        print("RoomChosen : \(roomChoice)")
//    }
    
    @IBAction func testeditingupdated(_ sender: UITextField) {
        updateDoneButtonState()
    }
    
    func updateDateViews(){
        checkinLabel.text = checkinDate.date.formatted(date: .abbreviated, time: .omitted)
        checkoutLabel.text = checkoutDate.date.formatted(date: .abbreviated, time: .omitted)
        checkoutDate.minimumDate = Calendar.current.date(byAdding: .day,value: 1, to: checkinDate.date)
    }
    
    
    @IBAction func datepickerchanged() {
        updateDateViews()
        updatesummary()
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath{
        case checkindateindexpath where checkinpickervisible == false:
            return 0
        case checkoutdateindexpath where checkoutpickervisible == false:
            return 0
        default:
            return UITableView.automaticDimension
        }
    }
    
    
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath {
        case checkindateindexpath:
            return 190
        case checkoutdateindexpath:
            return 190
        default:
            return UITableView.automaticDimension
        }
    }
    
    override func tableView(
        _ tableView: UITableView,
        didSelectRowAt indexPath: IndexPath
    ) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath == checkindatelabelindexpath && checkoutpickervisible == false{
            checkinpickervisible.toggle()
        }
        else if indexPath == checkoutdatelabelindexpath && checkinpickervisible == false{
            checkoutpickervisible.toggle()
        }
        else if indexPath == checkindatelabelindexpath || indexPath == checkoutdatelabelindexpath{
            checkinpickervisible.toggle()
            checkoutpickervisible.toggle()
        }
        else{
            return
        }
        tableView.beginUpdates()
        tableView.endUpdates()
    }
    
    func updateNumberOfGuets(){
        AdultCountLabel.text = "\(Int(AdultStepper.value))"
        ChildrenCountLabel.text = "\(Int(ChildrenStepper.value))"
    }
    
    @IBAction func stepperTapped(_ sender: UIStepper) {
        updateNumberOfGuets()
        updatesummary()
        updateDoneButtonState()
    }
    
    @IBAction func wifichanged(_ sender: UISwitch) {
        updatesummary()
        updateDoneButtonState()
    }
    
    func updateRoomType(){
        if let roomTypeReceived = roomTypeReceived{
            roomTypeLabel.text = roomTypeReceived.name
        }
        else{
            roomTypeLabel.text = "Not Set"
        }
    }
    
    func selectRoomTypeTableViewController(_ controller: SelectRoomTypeTableViewController, didSelect roomType: RoomType) {
        self.roomTypeReceived = roomType
        updateRoomType ()
        updatesummary()
        updateDoneButtonState()
    }
    
    
    @IBAction func cancelbuttontapped(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    func updateDoneButtonState(){
        DoneButton.isEnabled = (registeration != nil)
    }
    
    func updatesummary(){
        let nights = max(0,Calendar.current.dateComponents([.day],from: checkinDate.date,to: checkoutDate.date).day ?? 0)
        numofnights.text = "\(nights)"
        chargesduration.text = nights > 0 ? (checkinDate.date..<checkoutDate.date).formatted(date: .numeric, time: .omitted) : "—"
        
        if let room = roomTypeReceived, nights > 0 {
            let roomSubtotal = Double(room.price) * Double(nights)
            roomprices.text = "$ \(roomSubtotal)"
            typesofroom.text = "\(room.name) @ $\(room.price)/night"
           }
        else {
            roomprices.text = "$0.00"
            typesofroom.text = "Not Set"
           }
        
           let wifiRate = 10.0
           let wifiSubtotal = wifiSwitch.isOn ? wifiRate * Double(nights) : 0.0
           wifiprice.text = "$ \(wifiSubtotal)"
           wifichoice.text = wifiSwitch.isOn ? "Yes" : "No"
        
        let total = Double(roomTypeReceived?.price ?? 0) * Double(nights) + wifiSubtotal
        totalprice.text = "$ \(total)"
        
        updateDoneButtonState()
    }
    
    func loadregistereddata() {
        if let r = registereddata {
            
            fname.text = r.firstName
            lname.text = r.lastName
            email.text = r.emailAddress

           
            checkinDate.date = r.checkInDate
            checkoutDate.date = r.checkOutDate

            AdultStepper.value = Double(r.numberOfAdults)
            ChildrenStepper.value = Double(r.numberOfChildren)

            wifiSwitch.isOn = r.wifi
            roomTypeReceived = r.roomType

            updateRoomType()
            updateNumberOfGuets()
            updateDateViews()
            updatesummary()
        }
    }
    
    
}
