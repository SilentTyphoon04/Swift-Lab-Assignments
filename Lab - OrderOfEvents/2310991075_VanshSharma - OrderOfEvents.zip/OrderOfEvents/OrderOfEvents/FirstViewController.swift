//
//  ViewController.swift
//  OrderOfEvents
//
//  Created by Student on 30/07/25.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

