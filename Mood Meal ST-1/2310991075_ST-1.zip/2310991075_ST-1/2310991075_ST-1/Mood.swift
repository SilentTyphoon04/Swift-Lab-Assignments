//
//  Mood.swift
//  2310991075_ST-1
//
//  Created by Guest1 on 05/08/25.
//

import Foundation
//enum moods : String { case happy , sad, stressed, energetic }
//enum activityLevel : String { case sedentary , light, moderate , intense }

struct Mood{
    var emoji : String
    var name : String
}


struct Activity{
    var emoji : String
    var name : String
}

struct Meal{
    var mood : Mood
    var activity : Activity
    var suggestedMeal : String
}


var meals : [Meal] = [Meal(mood: Mood(emoji: "😊", name: "happy"), activity: Activity(emoji: "🪑", name: "sedentary"), suggestedMeal: "Meal1"),
                      Meal(mood: Mood(emoji: "😊", name: "happy"), activity: Activity(emoji: "🚶‍♂️", name: "light"), suggestedMeal: "Meal2"),
                      Meal(mood: Mood(emoji: "😊", name: "happy"), activity: Activity(emoji: "🏃", name: "moderate"), suggestedMeal: "Meal3"),
                      Meal(mood: Mood(emoji: "😊", name: "happy"), activity: Activity(emoji: "🏋️‍♂️", name: "intense"), suggestedMeal: "Meal4"),
                      Meal(mood: Mood(emoji: "😢", name: "sad"), activity: Activity(emoji: "🪑", name: "sedentary"), suggestedMeal: "Meal5"),
                           Meal(mood: Mood(emoji: "😢", name: "sad"), activity: Activity(emoji: "🚶‍♂️", name: "light"), suggestedMeal: "Meal6"),
                                Meal(mood: Mood(emoji: "😢", name: "sad"), activity: Activity(emoji: "🏃", name: "moderate"), suggestedMeal: "Meal7"),
                                     Meal(mood: Mood(emoji: "😢", name: "sad"), activity: Activity(emoji: "🏋️‍♂️", name: "intense"), suggestedMeal: "Meal8"),
                      Meal(mood: Mood(emoji: "😣", name: "stressed"), activity: Activity(emoji: "🪑", name: "sedentary"), suggestedMeal: "Meal9"),
                      Meal(mood: Mood(emoji: "😣", name: "stressed"), activity: Activity(emoji: "🚶‍♂️", name: "light"), suggestedMeal: "Meal10"),
                      Meal(mood: Mood(emoji: "😣", name: "stressed"), activity: Activity(emoji: "🏃", name: "moderate"), suggestedMeal: "Meal11"),
                      Meal(mood: Mood(emoji: "😣", name: "stressed"), activity: Activity(emoji: "🏋️‍♂️", name: "intense"), suggestedMeal: "Meal12"),
                      Meal(mood: Mood(emoji: "⚡️", name: "energetic"), activity: Activity(emoji: "🪑", name: "sedentary"), suggestedMeal: "Meal13"),
                      Meal(mood: Mood(emoji: "⚡️", name: "energetic"), activity: Activity(emoji: "🚶‍♂️", name: "light"), suggestedMeal: "Meal14"),
                      Meal(mood: Mood(emoji: "⚡️", name: "energetic"), activity: Activity(emoji: "🏃", name: "moderate"), suggestedMeal: "Meal15"),
                      Meal(mood: Mood(emoji: "⚡️", name: "energetic"), activity: Activity(emoji: "🏋️‍♂️", name: "intense"), suggestedMeal: "Meal16")]
 
