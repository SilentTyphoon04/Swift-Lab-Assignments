//
//  MoodViewController.swift
//  2310991075_ST-1
//
//  Created by Guest1 on 05/08/25.
//

import UIKit

class MoodViewController: UIViewController {

//    var moodSelected : moods?
    
    @IBOutlet weak var Button1: UIButton!
    @IBOutlet weak var Button2: UIButton!
    @IBOutlet weak var Button3: UIButton!
    @IBOutlet weak var Button4: UIButton!
    
    @IBOutlet weak var Label1: UILabel!
    @IBOutlet weak var Label2: UILabel!
    @IBOutlet weak var Label3: UILabel!
    @IBOutlet weak var Label4: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateData()
        // Do any additional setup after loading the view.
    }
    func populateData(){
//        Button1.setTitle("😊", for: .normal)
//        Button2.setTitle("🥲", for: .normal)
//        Button3.setTitle("😣", for: .normal)
//        Button4.setTitle("⚡️", for: .normal)
        
        Button1.setAttributedTitle(NSAttributedString(string: meals[0].mood.emoji, attributes: [.font: UIFont.systemFont(ofSize: 100)]), for: .normal)
        Button2.setAttributedTitle(NSAttributedString(string: meals[4].mood.emoji, attributes: [.font: UIFont.systemFont(ofSize: 100)]), for: .normal)
        Button3.setAttributedTitle(NSAttributedString(string: meals[8].mood.emoji, attributes: [.font: UIFont.systemFont(ofSize: 100)]), for: .normal)
        Button4.setAttributedTitle(NSAttributedString(string: meals[12].mood.emoji, attributes: [.font: UIFont.systemFont(ofSize: 100)]), for: .normal)
        
        
       // Button1.titleLabel?.font = UIFont.systemFont(ofSize: 150)
        
//        Label1.text = "Happy"
//        Label2.text = "Sad"
//        Label3.text = "Stressed"
//        Label4.text = "Energetic"
        Label1.text = meals[0].mood.name
        Label2.text = meals[4].mood.name
        Label3.text = meals[8].mood.name
        Label4.text = meals[12].mood.name
    }
    
//    @IBAction func Button1Tapped(_ sender: UIButton) {
//        moodSelected = .happy
//        performSegue(withIdentifier: "MoodToActivity", sender: nil)
//    }
//    
//    @IBAction func Button2Tapped(_ sender: UIButton) {
//        moodSelected = .sad
//        performSegue(withIdentifier: "MoodToActivity", sender: nil)
//    }
//    
//    @IBAction func Button3Tapped(_ sender: UIButton) {
//        moodSelected = .stressed
//        performSegue(withIdentifier: "MoodToActivity", sender: nil)
//    }
//    
//    @IBAction func Button4Tapped(_ sender: UIButton) {
//        moodSelected = .energetic
//        performSegue(withIdentifier: "MoodToActivity", sender: nil)
//    }
    
    @IBAction func ButtonTapped(_ sender: UIButton) {
        performSegue(withIdentifier: "MoodToActivity", sender: sender)
    }
    
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "MoodToActivity" {
//            if let destinationVC = segue.destination as? ActivityViewController {
//                destinationVC.moodReceived = moodSelected
//            }
//        }
//}
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let activityvc = segue.destination as? ActivityViewController else {
            return
        }
        guard let moodSelected = sender as? UIButton else {
            return
        }
        
        
        switch moodSelected{
        case Button1:
            activityvc.moodReceived = meals[0].mood
        case Button2:
            activityvc.moodReceived = meals[4].mood
        case Button3:
            activityvc.moodReceived = meals[8].mood
        case Button4:
            activityvc.moodReceived = meals[12].mood
        default:
            break
        }
        
        
        
       // activityvc.moodReceived = sender as? Mood ?? .self
}

}
