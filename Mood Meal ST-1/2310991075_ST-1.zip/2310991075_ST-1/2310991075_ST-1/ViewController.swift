//
//  ViewController.swift
//  2310991075_ST-1
//
//  Created by Guest1 on 05/08/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

