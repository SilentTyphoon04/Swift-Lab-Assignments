//
//  ActivityViewController.swift
//  2310991075_ST-1
//
//  Created by Guest1 on 05/08/25.
//

import UIKit

class ActivityViewController: UIViewController {

//    var moodReceived : moods?
    //var activityLevelChosen : activityLevel?
    
    var moodReceived : Mood?
    //var selectedactivity : Activity?
    
    
    @IBOutlet weak var Button1: UIButton!
    @IBOutlet weak var Button2: UIButton!
    @IBOutlet weak var Button3: UIButton!
    @IBOutlet weak var Button4: UIButton!
    
    @IBOutlet weak var Label1: UILabel!
    @IBOutlet weak var Label2: UILabel!
    @IBOutlet weak var Label3: UILabel!
    @IBOutlet weak var Label4: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateData()
        Button1.tag = 0
        Button2.tag = 1
        Button3.tag = 2
        Button4.tag = 3
        // Do any additional setup after loading the view.
    }
    
    func populateData(){
        Button1.setAttributedTitle(NSAttributedString(string:meals[0].activity.emoji, attributes: [.font : UIFont.systemFont(ofSize: 100)]), for: .normal)
        Button2.setAttributedTitle(NSAttributedString(string:meals[1].activity.emoji, attributes: [.font : UIFont.systemFont(ofSize: 100)]), for: .normal)
        Button3.setAttributedTitle(NSAttributedString(string:meals[2].activity.emoji, attributes: [.font : UIFont.systemFont(ofSize: 100)]), for: .normal)
        Button4.setAttributedTitle(NSAttributedString(string:meals[3].activity.emoji, attributes: [.font : UIFont.systemFont(ofSize: 100)]), for: .normal)
        
        Label1.text = meals[0].activity.name
        Label2.text = meals[1].activity.name
        Label3.text = meals[2].activity.name
        Label4.text = meals[3].activity.name
    }

//    @IBAction func Button1Tapped(_ sender: UIButton) {
//        activityLevelChosen = .sedentary
//        performSegue(withIdentifier: "mood2results", sender: nil)
//    }
//    @IBAction func Button2Tapped(_ sender: UIButton) {
//        activityLevelChosen = .light
//        performSegue(withIdentifier: "mood2results", sender: nil)
//    }
//    
//    @IBAction func Button3Tapped(_ sender: UIButton) {
//        activityLevelChosen = .moderate
//        performSegue(withIdentifier: "mood2results", sender: nil)
//    }
//    
//    @IBAction func Button4Tapped(_ sender: UIButton) {
//        activityLevelChosen = .intense
//        performSegue(withIdentifier: "mood2results", sender: nil)
//    }
//
    
    @IBAction func activityButtonTapped(_ sender: UIButton) {
//        switch sender{
//        case Button1:
//            selectedactivity = meals[0].activity
//        case Button2:
//            selectedactivity = meals[4].activity
//        case Button3:
//            selectedactivity = meals[8].activity
//        case Button4:
//            selectedactivity = meals[12].activity
//        default:
//            break
//        }
        performSegue(withIdentifier: "mood2results", sender: sender)
    }
    
    
    @IBSegueAction func passDataToResultsVC(_ coder: NSCoder, sender: Any?) -> ResultsViewController? {
        guard let button = sender as? UIButton, let mood = moodReceived else { return nil}
        let index = button.tag
        let selectedactivity = meals[index].activity
        return ResultsViewController(coder: coder,moodreceiver: mood, activityreceiver: selectedactivity)
    }
    
    
    
//    override func prepare(for segue: UIStoryboardSegue , sender: Any?){
//        if segue.identifier == "mood2results", let destinationVC = segue.destination as? ResultsViewController{
//            destinationVC.activityreceiver = selectedactivity
//            destinationVC.moodreceiver = moodReceived
//        }
//    }
//
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
