//
//  Question.swift
//  Personality Quiz
//
//  Created by Student on 29/07/25.
//

import Foundation

enum ResponseType{ case single, multiple, ranged }


struct Question {
    var text: String
    var answers: [Answer]
    var type: ResponseType
}


struct Answer{
    var text: String
    var country: CountryType
}


enum CountryType : Character{
    case japan = "🇯🇵", newZealand = "🇳🇿", maldives = "🇲🇻", greece = "🇬🇷"
    var definition : String {
        switch self{
        case .japan: return "You're the Cultured Cosmopolitan! You're drawn to a fascinating blend of ancient traditions and futuristic innovation. Japan offers unparalleled culinary experiences, bustling cities, serene temples, and a unique cultural immersion."
            
        case .newZealand: return "You're the Adventurous Explorer! You crave epic landscapes, thrilling activities, and a chance to truly connect with nature. New Zealand's diverse scenery, from mountains to coasts, and its vibrant adventure sports scene, make it your perfect match."
            
        case .maldives: return "You're the Ultimate Serenity Seeker! Your dream vacation is pure relaxation, luxury, and breathtaking natural beauty. The Maldives' idyllic beaches, crystal-clear waters, and focus on tranquility are exactly what you need to unwind."
            
        case .greece: return "You're the Immersive Historian & Cultural Enthusiast! You're passionate about ancient history, rich mythology, delicious food, and authentic local experiences. Greece offers a journey through time, vibrant island life, and warm hospitality."
        }
    }
}





var questions : [Question] = [
    Question(text: "What kind of climate do you generally prefer for your vacation ?", answers: [Answer(text: "Warm/Tropical", country: .maldives),Answer(text: "Mild/Pleasant", country: .japan),Answer(text: "Cool/Crisp", country: .newZealand),Answer(text: "Hot/Dry", country: .greece)], type: .single),
    
    Question(text: "Which of these activities are essential for your ideal vacation?", answers: [Answer(text: "Sunbathing, or lounging by water", country: .maldives),Answer(text: "Trying authentic local cuisine", country: .japan),Answer(text: "Hiking, adventuring, or extreme sports", country: .newZealand),Answer(text: "Exploring Museums/ Historical Sites", country: .greece)], type: .multiple),
    
    Question(text: "How important is it for you to disconnect from technology and daily life on your trip?", answers: [Answer(text: "Extremely Important", country: .maldives),Answer(text: "Somewhat Important", country: .greece),Answer(text: "Little Bit Important", country: .newZealand), Answer(text: "Not at all important", country: .japan)], type: .ranged)
]
