//
//  ViewController.swift
//  Login
//
//  Created by Student on 22/07/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var forgotUsernameButton: UIButton!
    @IBOutlet weak var forgotPasswordButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let sender = sender as? UIButton else { return }
        if sender == forgotPasswordButton{
            segue.destination.navigationItem.title = "Forgot Password"
        }
        else if sender == forgotUsernameButton{
            segue.destination.navigationItem.title = "Forgot Username"
        }
        else{
            segue.destination.navigationItem.title = username.text
        }
    }
    @IBAction func forgotUsernamePressed(_ sender: UIButton) {
        performSegue(withIdentifier: "vc1tovc2", sender: sender)
    }
    
    @IBAction func forgotPasswordPressed(_ sender: UIButton) {
        performSegue(withIdentifier: "vc1tovc2", sender: sender)
    }
    
}

